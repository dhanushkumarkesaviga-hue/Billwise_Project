import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import DashboardOverview from './components/DashboardOverview';
import OcrUploadScanner from './components/OcrUploadScanner';
import GstCategorizer from './components/GstCategorizer';
import TaxDeadlineTracker from './components/TaxDeadlineTracker';
import AiFinancialSummary from './components/AiFinancialSummary';
import InvoiceListTable from './components/InvoiceListTable';
import InvoiceDetailModal from './components/InvoiceDetailModal';
import AiCopilotDrawer from './components/AiCopilotDrawer';
import Login from './components/Login';

import { invoiceApi } from './api';
import { useAuth } from './context/AuthContext';

export default function App() {
  const { isAuthenticated, username, role, logout, hasRole } = useAuth();

  const [invoices, setInvoices] = useState([]);
  const [isLoadingInvoices, setIsLoadingInvoices] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isScanModalOpen, setIsScanModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);

  // VIEWER accounts are read-only on the backend (403 on create/update/
  // delete), so hide the actions that would just fail for them here too.
  const canManageInvoices = hasRole('ADMIN', 'ACCOUNTANT');

  // Load invoices from the Spring Boot backend on mount (only once logged in)
  useEffect(() => {
    if (!isAuthenticated) return undefined;

    let cancelled = false;
    setIsLoadingInvoices(true);

    invoiceApi.getAll()
      .then((data) => {
        if (!cancelled) setInvoices(data);
      })
      .catch((err) => {
        if (!cancelled) setLoadError(err.message);
      })
      .finally(() => {
        if (!cancelled) setIsLoadingInvoices(false);
      });

    return () => { cancelled = true; };
  }, []);

  // Keyboard shortcut Ctrl+K / Cmd+K for AI Copilot
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsCopilotOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleInvoiceScanned = (newInvoice) => {
    // OcrUploadScanner now persists the invoice to the backend itself and
    // passes back the saved record, so we just prepend it here.
    setInvoices(prev => [newInvoice, ...prev]);
    setIsScanModalOpen(false);
  };

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-rose-500 selection:text-white">
      
      {/* Navigation Bar */}
      <Navbar 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenScanModal={() => setIsScanModalOpen(true)}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        totalInvoicesCount={invoices.length}
        username={username}
        role={role}
        onLogout={logout}
        canManageInvoices={canManageInvoices}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-6 space-y-6">

        {loadError && (
          <div className="rounded-xl border border-rose-200 bg-rose-50 text-rose-700 text-sm px-4 py-3">
            Couldn't reach the BillWise backend ({loadError}). Make sure the Spring Boot
            app is running on port 8080.
          </div>
        )}

        {isLoadingInvoices && (
          <div className="rounded-xl border border-slate-200 bg-white text-slate-500 text-sm px-4 py-3">
            Loading invoices…
          </div>
        )}

        {activeTab === 'dashboard' && (
          <DashboardOverview 
            invoices={invoices}
            onOpenScanModal={() => setIsScanModalOpen(true)}
            setActiveTab={setActiveTab}
            onSelectInvoice={(inv) => setSelectedInvoice(inv)}
          />
        )}

        {activeTab === 'invoices' && (
          <InvoiceListTable 
            invoices={invoices}
            onOpenScanModal={() => setIsScanModalOpen(true)}
            onSelectInvoice={(inv) => setSelectedInvoice(inv)}
            canManageInvoices={canManageInvoices}
          />
        )}

        {activeTab === 'gst' && (
          <GstCategorizer 
            invoices={invoices}
            onSelectInvoice={(inv) => setSelectedInvoice(inv)}
          />
        )}

        {activeTab === 'deadlines' && (
          <TaxDeadlineTracker />
        )}

        {activeTab === 'insights' && (
          <AiFinancialSummary 
            invoices={invoices}
            onOpenCopilot={() => setIsCopilotOpen(true)}
          />
        )}

      </main>

      {/* OCR Scanner Upload Modal */}
      {isScanModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <OcrUploadScanner 
              onInvoiceScanned={handleInvoiceScanned}
              onClose={() => setIsScanModalOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Invoice Detail Modal */}
      {selectedInvoice && (
        <InvoiceDetailModal 
          invoice={selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
        />
      )}

      {/* AI Copilot Drawer */}
      <AiCopilotDrawer 
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        invoices={invoices}
      />

      {/* App Footer */}
      <footer className="border-t border-slate-900 py-6 text-center text-xs text-slate-400 bg-slate-950/50">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 BillWise AI Platform — MSME GST Compliance & Invoice Intelligence.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>OCR Accuracy: 98.4%</span>
            <span>•</span>
            <span>GSTR-1 Ready</span>
            <span>•</span>
            <span>Sec 17(5) Verified</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
