import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Download, 
  Eye, 
  Calendar, 
  ArrowUpDown,
  ScanLine
} from 'lucide-react';

export default function InvoiceListTable({ invoices, onOpenScanModal, onSelectInvoice, canManageInvoices }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [sortField, setSortField] = useState('invoiceDate');
  const [sortOrder, setSortOrder] = useState('desc');

  const filtered = invoices.filter(inv => {
    const matchesSearch = 
      inv.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.gstin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.hsnSac.includes(searchTerm);

    const matchesCategory = selectedCategory === 'ALL' || inv.category === selectedCategory;
    const matchesStatus = selectedStatus === 'ALL' || inv.status === selectedStatus;

    return matchesSearch && matchesCategory && matchesStatus;
  }).sort((a, b) => {
    let valA = a[sortField];
    let valB = b[sortField];

    if (typeof valA === 'string') {
      return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }
    return sortOrder === 'asc' ? valA - valB : valB - valA;
  });

  const exportToCsv = () => {
    const headers = ["Invoice ID,Vendor Name,GSTIN,Invoice No,Date,Category,HSN,Taxable,CGST,SGST,IGST,Total,ITC Status"];
    const rows = filtered.map(i => 
      `"${i.id}","${i.vendorName}","${i.gstin}","${i.invoiceNumber}","${i.invoiceDate}","${i.category}","${i.hsnSac}",${i.taxableAmount},${i.cgst},${i.sgst},${i.igst},${i.totalAmount},"${i.itcEligibility}"`
    );
    
    const blob = new Blob([[headers, ...rows].join("\n")], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `BillWise_Invoices_Export_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const categoriesList = Array.from(new Set(invoices.map(i => i.category)));

  return (
    <div className="space-y-6">
      
      {/* Top Action Bar */}
      <div className="glass-panel rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-rose-600" />
              Invoice Management Ledger
            </h1>
            <p className="text-xs text-slate-500">Total {invoices.length} OCR parsed invoices stored in ledger</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportToCsv}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-700 text-xs font-bold transition shadow-2xs"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              Export CSV
            </button>

            {canManageInvoices && (
              <button
                onClick={onOpenScanModal}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-bold text-xs shadow-md shadow-rose-600/20 transition"
              >
                <ScanLine className="w-4 h-4" />
                + Scan Invoice
              </button>
            )}
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search Vendor, GSTIN, Inv #, HSN..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs placeholder:text-slate-400 focus:border-rose-500 outline-none font-medium"
            />
          </div>

          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 text-xs focus:border-rose-500 outline-none font-medium"
            >
              <option value="ALL">All Categories</option>
              {categoriesList.map((cat, i) => (
                <option key={i} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 text-xs focus:border-rose-500 outline-none font-medium"
            >
              <option value="ALL">All Statuses</option>
              <option value="Approved">Approved</option>
              <option value="Pending">Pending</option>
              <option value="Flagged">Flagged</option>
            </select>
          </div>

        </div>
      </div>

      {/* Main Table */}
      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] uppercase tracking-wider text-slate-500 bg-slate-50">
                <th className="py-3.5 px-4 cursor-pointer hover:text-slate-900" onClick={() => { setSortField('vendorName'); setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc'); }}>
                  Vendor / Supplier <ArrowUpDown className="w-3 h-3 inline ml-1" />
                </th>
                <th className="py-3.5 px-4">Invoice # & Date</th>
                <th className="py-3.5 px-4">HSN / Category</th>
                <th className="py-3.5 px-4 cursor-pointer hover:text-slate-900" onClick={() => { setSortField('totalAmount'); setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc'); }}>
                  Total Amount <ArrowUpDown className="w-3 h-3 inline ml-1" />
                </th>
                <th className="py-3.5 px-4">GST Tax</th>
                <th className="py-3.5 px-4">ITC Status</th>
                <th className="py-3.5 px-4 text-right">Action</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 text-xs">
              {filtered.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50 transition group">
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900 group-hover:text-rose-600 transition">
                      {inv.vendorName}
                    </div>
                    <div className="text-[10px] font-mono text-rose-700 font-semibold mt-0.5">
                      GSTIN: {inv.gstin}
                    </div>
                  </td>

                  <td className="py-3.5 px-4">
                    <div className="font-mono text-slate-800 font-bold">{inv.invoiceNumber}</div>
                    <div className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {inv.invoiceDate}
                    </div>
                  </td>

                  <td className="py-3.5 px-4">
                    <div className="text-slate-800 font-medium">{inv.category}</div>
                    <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                      HSN: {inv.hsnSac}
                    </div>
                  </td>

                  <td className="py-3.5 px-4 font-mono font-extrabold text-slate-900">
                    ₹{inv.totalAmount.toLocaleString('en-IN')}
                  </td>

                  <td className="py-3.5 px-4 font-mono text-slate-700">
                    <div>₹{(inv.cgst + inv.sgst + inv.igst).toLocaleString('en-IN')}</div>
                    <div className="text-[10px] text-slate-500">Rate: {inv.gstRate}%</div>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                      inv.itcEligibility.includes('Eligible')
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}>
                      {inv.itcEligibility}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => onSelectInvoice(inv)}
                      className="p-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition shadow-2xs"
                      title="View Invoice Tax Breakdown"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
