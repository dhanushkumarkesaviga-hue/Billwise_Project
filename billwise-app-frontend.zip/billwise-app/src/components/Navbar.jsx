import React from 'react';
import { 
  ScanLine, 
  FileText, 
  PieChart, 
  CalendarClock, 
  Bot, 
  ShieldCheck, 
  Plus, 
  Sparkles,
  UserCircle2,
  LogOut
} from 'lucide-react';

const ROLE_STYLES = {
  ADMIN: 'bg-rose-50 text-rose-700 border-rose-200',
  ACCOUNTANT: 'bg-blue-50 text-blue-700 border-blue-200',
  VIEWER: 'bg-slate-100 text-slate-600 border-slate-200',
};

export default function Navbar({
  activeTab, setActiveTab, onOpenScanModal, onOpenCopilot, totalInvoicesCount,
  username, role, onLogout, canManageInvoices,
}) {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 lg:px-8 py-3 shadow-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Brand & Logo */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 via-red-500 to-rose-400 p-0.5 shadow-md shadow-rose-500/20">
              <div className="w-full h-full bg-white rounded-[10px] flex items-center justify-center">
                <ScanLine className="w-5 h-5 text-rose-600 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-slate-900">
                  Bill<span className="text-rose-600">Wise</span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-50 text-rose-600 border border-rose-200">
                  Red Series
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">MSME Invoice & GST Platform</p>
            </div>
          </div>

          {/* Quick Upload CTA (Mobile) */}
          {canManageInvoices && (
            <button 
              onClick={onOpenScanModal}
              className="md:hidden flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-medium text-xs shadow-sm transition"
            >
              <Plus className="w-4 h-4" />
              Scan
            </button>
          )}
        </div>

        {/* Navigation Links */}
        <nav className="flex items-center gap-1 overflow-x-auto w-full md:w-auto py-1 no-scrollbar">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'bg-rose-50 text-rose-700 border border-rose-200 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <PieChart className="w-4 h-4" />
            Dashboard
          </button>

          <button
            onClick={() => setActiveTab('invoices')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'invoices'
                ? 'bg-rose-50 text-rose-700 border border-rose-200 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            Invoices
            <span className="ml-1 text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-700">
              {totalInvoicesCount}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('gst')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'gst'
                ? 'bg-rose-50 text-rose-700 border border-rose-200 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            GST & ITC
          </button>

          <button
            onClick={() => setActiveTab('deadlines')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'deadlines'
                ? 'bg-rose-50 text-rose-700 border border-rose-200 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CalendarClock className="w-4 h-4" />
            Deadlines
            <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
          </button>

          <button
            onClick={() => setActiveTab('insights')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'insights'
                ? 'bg-rose-50 text-rose-700 border border-rose-200 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Sparkles className="w-4 h-4 text-emerald-600" />
            AI Summary
          </button>
        </nav>

        {/* Right CTAs */}
        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={onOpenCopilot}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:text-rose-600 hover:border-rose-300 text-xs font-bold transition shadow-xs group"
          >
            <Bot className="w-4 h-4 text-rose-600 group-hover:scale-110 transition" />
            <span>BillWise AI</span>
            <span className="px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 text-[10px] font-mono border border-rose-200">Ctrl+K</span>
          </button>

          {canManageInvoices && (
            <button 
              onClick={onOpenScanModal}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-bold text-xs shadow-md shadow-rose-600/20 transition hover:scale-[1.02]"
            >
              <ScanLine className="w-4 h-4" />
              Scan Invoice (OCR)
            </button>
          )}

          {/* User badge & logout */}
          <div className="flex items-center gap-2 pl-3 ml-1 border-l border-slate-200">
            <div className="flex items-center gap-1.5">
              <UserCircle2 className="w-5 h-5 text-slate-400" />
              <div className="leading-tight">
                <div className="text-xs font-bold text-slate-800">{username}</div>
                <span className={`text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-full border ${ROLE_STYLES[role] ?? ROLE_STYLES.VIEWER}`}>
                  {role}
                </span>
              </div>
            </div>
            <button
              onClick={onLogout}
              title="Log out"
              className="p-2 rounded-xl bg-white border border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-300 transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </header>
  );
}
