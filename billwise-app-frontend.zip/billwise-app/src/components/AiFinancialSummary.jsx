import React from 'react';
import { 
  Sparkles, 
  Bot, 
  Lightbulb, 
  PieChart as PieIcon,
  BarChart3
} from 'lucide-react';

export default function AiFinancialSummary({ invoices, onOpenCopilot }) {
  const totalSpend = invoices.reduce((acc, inv) => acc + inv.totalAmount, 0);
  const eligibleItc = invoices
    .filter(inv => inv.itcEligibility.includes('Eligible'))
    .reduce((acc, inv) => acc + inv.itcAmount, 0);

  const blockedItc = invoices
    .filter(inv => inv.itcEligibility.includes('Ineligible'))
    .reduce((acc, inv) => acc + (inv.cgst + inv.sgst + inv.igst), 0);

  const categoriesMap = invoices.reduce((acc, inv) => {
    acc[inv.category] = (acc[inv.category] || 0) + inv.totalAmount;
    return acc;
  }, {});

  const categoryItems = Object.keys(categoriesMap).map(cat => ({
    name: cat,
    amount: categoriesMap[cat],
    percentage: Math.round((categoriesMap[cat] / totalSpend) * 100)
  })).sort((a, b) => b.amount - a.amount);

  return (
    <div className="space-y-6">
      
      {/* Executive AI Header */}
      <div className="glass-panel-glow rounded-2xl p-6 md:p-8 space-y-4 relative border border-rose-200">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 text-rose-700 text-xs font-bold border border-rose-200">
              <Sparkles className="w-3.5 h-3.5 text-rose-600" />
              AI Executive Financial Digest • FY 2026-27 Q2
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900">
              Smart Tax & Financial Health Digest
            </h1>
            <p className="text-xs text-slate-500 max-w-2xl">
              Generated automatically by analyzing your OCR scanned invoices, HSN classifications, and GSTR compliance records.
            </p>
          </div>

          <button
            onClick={onOpenCopilot}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-bold text-xs shadow-md shadow-rose-600/20 transition hover:scale-[1.02]"
          >
            <Bot className="w-4 h-4" />
            Ask BillWise AI Assistant
          </button>
        </div>

        {/* AI Key Insights Box */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
          <h3 className="text-xs font-bold text-rose-700 uppercase tracking-wider flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-amber-500" />
            AI Auditor Observations:
          </h3>

          <ul className="space-y-2 text-xs text-slate-700">
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0"></span>
              <span>
                <strong className="text-slate-900">ITC Optimization:</strong> You have accumulated <strong className="text-emerald-700">₹{eligibleItc.toLocaleString('en-IN')}</strong> in claimable Input Tax Credit across {invoices.filter(i => i.itcEligibility.includes('Eligible')).length} invoices. This directly reduces your cash tax liability in GSTR-3B.
              </span>
            </li>

            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0"></span>
              <span>
                <strong className="text-slate-900">Blocked Credit Audit:</strong> <strong className="text-amber-700">₹{blockedItc.toLocaleString('en-IN')}</strong> of GST paid on food & entertainment is marked as blocked under Sec 17(5)(b). It cannot be claimed as tax credit.
              </span>
            </li>

            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600 mt-1.5 shrink-0"></span>
              <span>
                <strong className="text-slate-900">Top Expense Driver:</strong> <strong className="text-rose-700">{categoryItems[0]?.name || 'Capital Goods'}</strong> accounts for <strong className="text-slate-900">{categoryItems[0]?.percentage || 0}%</strong> of total expenditure this period.
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Visual Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left: Category Expense Breakdown */}
        <div className="glass-panel rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-rose-600" />
              Expense Distribution by Category
            </h3>
            <span className="text-xs text-slate-500 font-mono">Total: ₹{totalSpend.toLocaleString('en-IN')}</span>
          </div>

          <div className="space-y-3 pt-2">
            {categoryItems.map((cat, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800">{cat.name}</span>
                  <span className="font-mono text-slate-500">
                    ₹{cat.amount.toLocaleString('en-IN')} ({cat.percentage}%)
                  </span>
                </div>

                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                  <div 
                    className="h-full bg-gradient-to-r from-rose-500 to-red-600 rounded-full transition-all duration-500"
                    style={{ width: `${cat.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Monthly Financial Trend Forecast */}
        <div className="glass-panel rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-600" />
              Monthly Spend & Tax Trajectory
            </h3>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Audited OK
            </span>
          </div>

          {/* SVG Bar Chart Visualization */}
          <div className="h-52 flex items-end justify-between gap-4 pt-6 px-4 pb-2 border-b border-slate-100">
            {[
              { month: 'May', spend: 180000, tax: 28000 },
              { month: 'Jun', spend: 240000, tax: 38000 },
              { month: 'Jul', spend: 310000, tax: 49000 },
              { month: 'Aug (Cur)', spend: totalSpend, tax: eligibleItc }
            ].map((bar, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <div className="w-full max-w-[44px] flex items-end gap-1 h-full">
                  <div 
                    className="w-1/2 bg-rose-500 rounded-t transition-all group-hover:bg-rose-600"
                    style={{ height: `${(bar.spend / 350000) * 100}%` }}
                    title={`Spend: ₹${bar.spend.toLocaleString()}`}
                  ></div>
                  <div 
                    className="w-1/2 bg-emerald-500 rounded-t transition-all group-hover:bg-emerald-600"
                    style={{ height: `${(bar.tax / 80000) * 100}%` }}
                    title={`Tax Credit: ₹${bar.tax.toLocaleString()}`}
                  ></div>
                </div>
                <span className="text-[11px] font-mono text-slate-500 font-semibold">{bar.month}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-6 text-xs pt-1">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-rose-500 rounded-sm"></span>
              <span className="text-slate-700 font-semibold">Total Spend</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-emerald-500 rounded-sm"></span>
              <span className="text-slate-700 font-semibold">ITC Claimed</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
