import React, { useState } from 'react';
import { ScanLine, Lock, Mail, User, ShieldCheck, Eye, EyeOff, LogIn, UserPlus } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const ROLE_OPTIONS = [
  { value: 'VIEWER', label: 'Viewer (read-only)' },
  { value: 'ACCOUNTANT', label: 'Accountant (create & manage invoices)' },
  { value: 'ADMIN', label: 'Admin (full access)' },
];

export default function Login() {
  const { login, register, isAuthLoading, authError } = useAuth();
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [showPassword, setShowPassword] = useState(false);

  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('VIEWER');
  const [localError, setLocalError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLocalError(null);
    try {
      if (mode === 'login') {
        await login(username, password);
      } else {
        await register(username, email, password, role);
      }
    } catch {
      // authError from context already surfaces the message; nothing else to do.
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">

        {/* Brand */}
        <div className="flex flex-col items-center gap-2 mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-600 via-red-500 to-rose-400 p-0.5 shadow-md shadow-rose-500/20">
            <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center">
              <ScanLine className="w-7 h-7 text-rose-600" />
            </div>
          </div>
          <span className="font-extrabold text-2xl tracking-tight text-slate-900">
            Bill<span className="text-rose-600">Wise</span>
          </span>
          <p className="text-xs text-slate-500 font-medium">MSME Invoice & GST Platform</p>
        </div>

        {/* Card */}
        <div className="glass-panel bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-lg space-y-6">

          {/* Mode toggle */}
          <div className="flex items-center rounded-xl bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => { setMode('login'); setLocalError(null); }}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition ${
                mode === 'login' ? 'bg-white shadow-sm text-rose-600' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" /> Log in
            </button>
            <button
              type="button"
              onClick={() => { setMode('register'); setLocalError(null); }}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition ${
                mode === 'register' ? 'bg-white shadow-sm text-rose-600' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" /> Create account
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">

            <div>
              <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500 mb-1 block">
                Username
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. admin"
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-sm placeholder:text-slate-400 focus:border-rose-500 outline-none font-medium"
                />
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500 mb-1 block">
                  Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-sm placeholder:text-slate-400 focus:border-rose-500 outline-none font-medium"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500 mb-1 block">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={mode === 'register' ? 6 : undefined}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-9 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-sm placeholder:text-slate-400 focus:border-rose-500 outline-none font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500 mb-1 block">
                  Role
                </label>
                <div className="relative">
                  <ShieldCheck className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-sm focus:border-rose-500 outline-none font-medium appearance-none"
                  >
                    {ROLE_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {(authError || localError) && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 text-rose-700 text-xs px-3 py-2.5">
                {authError || localError}
              </div>
            )}

            <button
              type="submit"
              disabled={isAuthLoading}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 disabled:opacity-60 text-white font-bold text-sm shadow-md shadow-rose-600/20 transition"
            >
              {isAuthLoading ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Create account'}
            </button>
          </form>

          {mode === 'login' && (
            <div className="text-[11px] text-slate-500 bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-1">
              <p className="font-bold text-slate-600">Demo logins (local dev seed data):</p>
              <p><span className="font-mono">admin</span> / <span className="font-mono">Admin@123</span> — full access</p>
              <p><span className="font-mono">accountant</span> / <span className="font-mono">Accountant@123</span> — manage invoices</p>
              <p><span className="font-mono">viewer</span> / <span className="font-mono">Viewer@123</span> — read-only</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
