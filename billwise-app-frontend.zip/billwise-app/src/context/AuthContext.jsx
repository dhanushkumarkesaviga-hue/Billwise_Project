import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authApi } from '../api';

const AuthContext = createContext(null);

const STORAGE_KEY = 'billwise_auth';

function readStoredAuth() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

// Central place for auth state: who's logged in, their role, and the JWT
// used to authenticate every API call. Persisted to localStorage so a page
// refresh doesn't log the user out.
export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(() => readStoredAuth());
  const [authError, setAuthError] = useState(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);

  useEffect(() => {
    if (auth) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(auth));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [auth]);

  // If some other part of the app (api.js) detects a 401/expired token,
  // it dispatches this event so we log out everywhere consistently.
  useEffect(() => {
    const handleForceLogout = () => setAuth(null);
    window.addEventListener('billwise:unauthorized', handleForceLogout);
    return () => window.removeEventListener('billwise:unauthorized', handleForceLogout);
  }, []);

  const login = useCallback(async (username, password) => {
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      const data = await authApi.login(username, password);
      setAuth(data);
      return data;
    } catch (err) {
      setAuthError(err.message);
      throw err;
    } finally {
      setIsAuthLoading(false);
    }
  }, []);

  const register = useCallback(async (username, email, password, role) => {
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      const data = await authApi.register(username, email, password, role);
      setAuth(data);
      return data;
    } catch (err) {
      setAuthError(err.message);
      throw err;
    } finally {
      setIsAuthLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    setAuth(null);
  }, []);

  const value = useMemo(() => ({
    token: auth?.token ?? null,
    username: auth?.username ?? null,
    email: auth?.email ?? null,
    role: auth?.role ?? null,
    isAuthenticated: Boolean(auth?.token),
    isAuthLoading,
    authError,
    login,
    register,
    logout,
    // Convenience helper for role gated UI, e.g. hasRole('ADMIN', 'ACCOUNTANT')
    hasRole: (...roles) => Boolean(auth?.role) && roles.includes(auth.role),
  }), [auth, isAuthLoading, authError, login, register, logout]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
