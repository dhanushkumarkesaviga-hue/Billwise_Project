const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8080/api';

const STORAGE_KEY = 'billwise_auth';

function getToken() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw)?.token : null;
  } catch {
    return null;
  }
}

function authHeaders() {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function handleResponse(res) {
  if (res.status === 401) {
    // Token missing/expired/invalid - clear local session and let the
    // AuthProvider redirect back to the login screen.
    localStorage.removeItem(STORAGE_KEY);
    window.dispatchEvent(new Event('billwise:unauthorized'));
  }

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.message) message = body.message;
    } catch {
      // ignore non-JSON error bodies
    }
    throw new Error(message);
  }
  // 204 No Content has no body to parse
  if (res.status === 204) return null;
  return res.json();
}

export const authApi = {
  login: (username, password) =>
    fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    }).then(handleResponse),

  register: (username, email, password, role) =>
    fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password, role }),
    }).then(handleResponse),

  me: () =>
    fetch(`${API_BASE}/auth/me`, {
      headers: { ...authHeaders() },
    }).then(handleResponse),
};

export const invoiceApi = {
  getAll: () => fetch(`${API_BASE}/invoices`, { headers: { ...authHeaders() } }).then(handleResponse),

  getById: (id) => fetch(`${API_BASE}/invoices/${id}`, { headers: { ...authHeaders() } }).then(handleResponse),

  create: (invoice) =>
    fetch(`${API_BASE}/invoices`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify(invoice),
    }).then(handleResponse),

  update: (id, invoice) =>
    fetch(`${API_BASE}/invoices/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify(invoice),
    }).then(handleResponse),

  updateStatus: (id, { status, paymentStatus }) =>
    fetch(`${API_BASE}/invoices/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ status, paymentStatus }),
    }).then(handleResponse),

  remove: (id) =>
    fetch(`${API_BASE}/invoices/${id}`, { method: 'DELETE', headers: { ...authHeaders() } }).then(handleResponse),

  getStats: () => fetch(`${API_BASE}/invoices/stats`, { headers: { ...authHeaders() } }).then(handleResponse),

  classify: (ocrText, vendorNameHint) =>
    fetch(`${API_BASE}/invoices/classify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ ocrText, vendorNameHint }),
    }).then(handleResponse),
};

export const deadlineApi = {
  getAll: () => fetch(`${API_BASE}/deadlines`, { headers: { ...authHeaders() } }).then(handleResponse),
};

export const copilotApi = {
  getSessionId: () => {
    let sessionId = localStorage.getItem('billwise_copilot_session');
    if (!sessionId) {
      sessionId = crypto.randomUUID();
      localStorage.setItem('billwise_copilot_session', sessionId);
    }
    return sessionId;
  },

  getHistory: (sessionId) =>
    fetch(`${API_BASE}/copilot/history/${sessionId}`, { headers: { ...authHeaders() } }).then(handleResponse),

  sendMessage: (sessionId, message) =>
    fetch(`${API_BASE}/copilot/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ sessionId, message }),
    }).then(handleResponse),

  clearHistory: (sessionId) =>
    fetch(`${API_BASE}/copilot/history/${sessionId}`, { method: 'DELETE', headers: { ...authHeaders() } }).then(handleResponse),
};
