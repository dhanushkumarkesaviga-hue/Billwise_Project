package com.billwise.backend.controller;

import com.billwise.backend.dto.ClassifyRequest;
import com.billwise.backend.dto.ClassifyResponse;
import com.billwise.backend.entity.Invoice;
import com.billwise.backend.service.InvoiceClassificationService;
import com.billwise.backend.service.InvoiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;
    private final InvoiceClassificationService classificationService;

    // Any authenticated role (ADMIN, ACCOUNTANT, VIEWER) can read invoices.
    @GetMapping
    public List<Invoice> getAllInvoices() {
        return invoiceService.getAllInvoices();
    }

    @GetMapping("/{id}")
    public Invoice getInvoice(@PathVariable String id) {
        return invoiceService.getInvoiceById(id);
    }

    // VIEWER accounts are read-only and cannot create records.
    @PreAuthorize("hasAnyRole('ADMIN', 'ACCOUNTANT')")
    @PostMapping
    public ResponseEntity<Invoice> createInvoice(@Valid @RequestBody Invoice invoice) {
        Invoice saved = invoiceService.createInvoice(invoice);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'ACCOUNTANT')")
    @PutMapping("/{id}")
    public Invoice updateInvoice(@PathVariable String id, @Valid @RequestBody Invoice invoice) {
        return invoiceService.updateInvoice(id, invoice);
    }

    // Quick-action endpoint for buttons like "Approve", "Flag", "Mark as Paid"
    @PreAuthorize("hasAnyRole('ADMIN', 'ACCOUNTANT')")
    @PatchMapping("/{id}/status")
    public Invoice updateStatus(@PathVariable String id, @RequestBody Map<String, String> body) {
        return invoiceService.updateStatus(id, body.get("status"), body.get("paymentStatus"));
    }

    // Deleting records is admin-only.
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInvoice(@PathVariable String id) {
        invoiceService.deleteInvoice(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/stats")
    public Map<String, Object> getDashboardStats() {
        return invoiceService.getDashboardStats();
    }

    // AI-powered category classification, called by the frontend right
    // after OCR extracts raw text and before the invoice is saved.
    @PreAuthorize("hasAnyRole('ADMIN', 'ACCOUNTANT')")
    @PostMapping("/classify")
    public ClassifyResponse classify(@Valid @RequestBody ClassifyRequest request) {
        return classificationService.classify(request.getOcrText(), request.getVendorNameHint());
    }
}
