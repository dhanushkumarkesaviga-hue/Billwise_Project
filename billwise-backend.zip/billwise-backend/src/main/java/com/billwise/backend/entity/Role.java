package com.billwise.backend.entity;

// Role based access control:
//  - ADMIN       full access: manage invoices, users, and delete records.
//  - ACCOUNTANT  day-to-day operator: create/edit/approve invoices, cannot manage users.
//  - VIEWER      read-only access to dashboards, invoices, and reports.
public enum Role {
    ADMIN,
    ACCOUNTANT,
    VIEWER
}
