package com.billwise.backend.repository;

import com.billwise.backend.entity.Invoice;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface InvoiceRepository extends MongoRepository<Invoice, String> {

    List<Invoice> findByStatus(String status);

    List<Invoice> findByPaymentStatus(String paymentStatus);

    List<Invoice> findByItcEligibilityContainingIgnoreCase(String keyword);
}
