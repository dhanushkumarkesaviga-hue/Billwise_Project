package com.billwise.backend.config;

import com.billwise.backend.entity.GstDeadline;
import com.billwise.backend.entity.Invoice;
import com.billwise.backend.entity.Role;
import com.billwise.backend.entity.User;
import com.billwise.backend.repository.GstDeadlineRepository;
import com.billwise.backend.repository.InvoiceRepository;
import com.billwise.backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

// Seeds the same demo data that used to live in the frontend's
// mockInvoices.js / gstDeadlines.js, so the dashboard isn't empty the first
// time you point the React app at this backend. Only runs if the tables
// are empty, so it never overwrites real data.
@Slf4j
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final InvoiceRepository invoiceRepository;
    private final GstDeadlineRepository gstDeadlineRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        seedInvoices();
        seedDeadlines();
        seedUsers();
    }

    // Creates one demo login per role so role based access can be tried
    // out immediately. Change these passwords (or delete the users) before
    // using this in anything beyond local development.
    private void seedUsers() {
        if (userRepository.count() > 0) return;

        userRepository.save(user("admin", "admin@billwise.app", "Admin@123", Role.ADMIN));
        userRepository.save(user("accountant", "accountant@billwise.app", "Accountant@123", Role.ACCOUNTANT));
        userRepository.save(user("viewer", "viewer@billwise.app", "Viewer@123", Role.VIEWER));

        log.info("Seeded demo users - admin/Admin@123, accountant/Accountant@123, viewer/Viewer@123");
    }

    private User user(String username, String email, String rawPassword, Role role) {
        User u = new User();
        u.setUsername(username);
        u.setEmail(email);
        u.setPassword(passwordEncoder.encode(rawPassword));
        u.setRole(role);
        return u;
    }

    private void seedInvoices() {
        if (invoiceRepository.count() > 0) return;

        invoiceRepository.save(invoice("INV-2026-0891", "Apex Cloud Technologies Pvt Ltd", "27AAACA1234F1Z5",
                "ACT-89104", LocalDate.of(2026, 7, 28), LocalDate.of(2026, 8, 27),
                "Cloud Infrastructure", "998313", "45000", 18, "4050", "4050", "0", "53100",
                "Eligible", "8100", false, "Approved", "Paid", 98.4,
                "Monthly server hosting & load balancer setup"));

        invoiceRepository.save(invoice("INV-2026-0892", "National Logistics & Freight Solutions", "07BBBCC5678G2Z9",
                "NLFS/AUG/102", LocalDate.of(2026, 8, 1), LocalDate.of(2026, 8, 15),
                "Freight & Transport", "996511", "28500", 5, "0", "0", "1425", "29925",
                "Eligible (RCM)", "1425", true, "Pending", "Unpaid", 96.1,
                "Goods transport agency charges for North Zone delivery"));

        invoiceRepository.save(invoice("INV-2026-0893", "ErgoFurniture Works India", "29DDDEE9012H3Z1",
                "EFW-2026-991", LocalDate.of(2026, 7, 15), LocalDate.of(2026, 8, 14),
                "Capital Goods & Office Assets", "940330", "120000", 28, "16800", "16800", "0", "153600",
                "Eligible", "33600", false, "Approved", "Paid", 99.1,
                "Ergonomic mesh chairs and standing desks for team expansion"));

        invoiceRepository.save(invoice("INV-2026-0894", "Grand Palace Hotel & Catering", "07AAACG9988K1Z3",
                "GPH-4412", LocalDate.of(2026, 7, 29), LocalDate.of(2026, 7, 29),
                "Food & Entertainment", "996331", "14200", 5, "355", "355", "0", "14910",
                "Ineligible (Sec 17(5))", "0", false, "Flagged", "Paid", 94.8,
                "Client dinner & catering event - Blocked ITC under GST Sec 17(5)(b)"));

        invoiceRepository.save(invoice("INV-2026-0895", "Mahavir Industrial Hardware & Tools", "27KKKLL4455M1Z8",
                "MIH/26-27/044", LocalDate.of(2026, 8, 2), LocalDate.of(2026, 8, 31),
                "Raw Materials", "731815", "84000", 18, "7560", "7560", "0", "99120",
                "Eligible", "15120", false, "Pending", "Unpaid", 97.2,
                "Stainless steel fasteners & industrial hardware batch #3"));
    }

    private void seedDeadlines() {
        if (gstDeadlineRepository.count() > 0) return;

        gstDeadlineRepository.save(deadline("gstr-1-aug", "GSTR-1", "Outward Supplies Return", "Monthly",
                LocalDate.of(2026, 8, 11), "Upcoming",
                "Details of all outward supplies (sales) made during July 2026 for regular taxpayers with turnover > Rs. 5 Cr.",
                50, 10000, "High - Delay blocks ITC pass-through to your buyers in GSTR-2B"));

        gstDeadlineRepository.save(deadline("gstr-3b-aug", "GSTR-3B", "Summary Tax Return & Payment", "Monthly",
                LocalDate.of(2026, 8, 20), "Upcoming",
                "Self-assessed monthly summary return for tax payment and ITC claim for July 2026.",
                50, 10000, "Critical - Requires cash payment or net ITC offset against output liability"));

        gstDeadlineRepository.save(deadline("iff-qrmp", "GSTR-1 (IFF)", "Invoice Furnishing Facility (QRMP)",
                "Monthly (Optional)", LocalDate.of(2026, 8, 13), "Optional",
                "Optional facility for quarterly filers to pass ITC to B2B customers for Month 1 & 2.",
                0, 0, "Medium - Facilitates faster ITC claim for buyers"));

        gstDeadlineRepository.save(deadline("cmp-08-q2", "CMP-08", "Composition Tax Payment Statement",
                "Quarterly", LocalDate.of(2026, 10, 18), "Upcoming",
                "Quarterly self-assessed tax payment statement for Composition Scheme taxpayers (Q2 FY 2026-27).",
                50, 2000, "Medium - Flat rate tax payment based on turnover"));

        gstDeadlineRepository.save(deadline("gstr-9-fy26", "GSTR-9 & 9C", "Annual GST Return & Reconciliation",
                "Annual", LocalDate.of(2026, 12, 31), "Scheduled",
                "Annual consolidated return and audit reconciliation statement for FY 2025-26.",
                200, 25000, "High - Final opportunity to rectify ITC mismatches"));
    }

    private Invoice invoice(String id, String vendorName, String gstin, String invoiceNumber,
                             LocalDate invoiceDate, LocalDate dueDate, String category, String hsnSac,
                             String taxableAmount, double gstRate, String cgst, String sgst, String igst,
                             String totalAmount, String itcEligibility, String itcAmount, boolean rcmApplicable,
                             String status, String paymentStatus, double ocrConfidence, String notes) {
        Invoice inv = new Invoice();
        inv.setId(id);
        inv.setVendorName(vendorName);
        inv.setGstin(gstin);
        inv.setInvoiceNumber(invoiceNumber);
        inv.setInvoiceDate(invoiceDate);
        inv.setDueDate(dueDate);
        inv.setCategory(category);
        inv.setHsnSac(hsnSac);
        inv.setTaxableAmount(new BigDecimal(taxableAmount));
        inv.setGstRate(gstRate);
        inv.setCgst(new BigDecimal(cgst));
        inv.setSgst(new BigDecimal(sgst));
        inv.setIgst(new BigDecimal(igst));
        inv.setTotalAmount(new BigDecimal(totalAmount));
        inv.setItcEligibility(itcEligibility);
        inv.setItcAmount(new BigDecimal(itcAmount));
        inv.setRcmApplicable(rcmApplicable);
        inv.setStatus(status);
        inv.setPaymentStatus(paymentStatus);
        inv.setOcrConfidence(ocrConfidence);
        inv.setNotes(notes);
        return inv;
    }

    private GstDeadline deadline(String id, String formName, String title, String frequency, LocalDate dueDate,
                                  String status, String description, int lateFeePerDay, int maxPenalty,
                                  String impact) {
        GstDeadline d = new GstDeadline();
        d.setId(id);
        d.setFormName(formName);
        d.setTitle(title);
        d.setFrequency(frequency);
        d.setDueDate(dueDate);
        d.setStatus(status);
        d.setDescription(description);
        d.setLateFeePerDay(lateFeePerDay);
        d.setMaxPenalty(maxPenalty);
        d.setImpact(impact);
        return d;
    }
}
