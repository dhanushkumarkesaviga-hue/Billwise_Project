package com.billwise.backend.service;

import com.billwise.backend.entity.Invoice;
import com.billwise.backend.exception.ResourceNotFoundException;
import com.billwise.backend.repository.InvoiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Year;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;

    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }

    public Invoice getInvoiceById(String id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found: " + id));
    }

    public Invoice createInvoice(Invoice invoice) {
        if (invoice.getId() == null || invoice.getId().isBlank()) {
            invoice.setId(generateInvoiceId());
        }
        return invoiceRepository.save(invoice);
    }

    public Invoice updateInvoice(String id, Invoice updated) {
        Invoice existing = getInvoiceById(id);

        existing.setVendorName(updated.getVendorName());
        existing.setGstin(updated.getGstin());
        existing.setInvoiceNumber(updated.getInvoiceNumber());
        existing.setInvoiceDate(updated.getInvoiceDate());
        existing.setDueDate(updated.getDueDate());
        existing.setCategory(updated.getCategory());
        existing.setHsnSac(updated.getHsnSac());
        existing.setTaxableAmount(updated.getTaxableAmount());
        existing.setGstRate(updated.getGstRate());
        existing.setCgst(updated.getCgst());
        existing.setSgst(updated.getSgst());
        existing.setIgst(updated.getIgst());
        existing.setTotalAmount(updated.getTotalAmount());
        existing.setItcEligibility(updated.getItcEligibility());
        existing.setItcAmount(updated.getItcAmount());
        existing.setRcmApplicable(updated.isRcmApplicable());
        existing.setStatus(updated.getStatus());
        existing.setPaymentStatus(updated.getPaymentStatus());
        existing.setOcrConfidence(updated.getOcrConfidence());
        existing.setNotes(updated.getNotes());
        existing.setRawFileUrl(updated.getRawFileUrl());

        return invoiceRepository.save(existing);
    }

    // Lightweight update for quick actions like the frontend's
    // "mark as paid" / "approve" / "flag" buttons.
    public Invoice updateStatus(String id, String status, String paymentStatus) {
        Invoice existing = getInvoiceById(id);
        if (status != null) existing.setStatus(status);
        if (paymentStatus != null) existing.setPaymentStatus(paymentStatus);
        return invoiceRepository.save(existing);
    }

    public void deleteInvoice(String id) {
        if (!invoiceRepository.existsById(id)) {
            throw new ResourceNotFoundException("Invoice not found: " + id);
        }
        invoiceRepository.deleteById(id);
    }

    // Server-side aggregates for the dashboard / AI copilot, mirroring the
    // calculations the frontend previously did client-side over mock data.
    public Map<String, Object> getDashboardStats() {
        List<Invoice> invoices = invoiceRepository.findAll();

        BigDecimal totalSpend = invoices.stream()
                .map(Invoice::getTotalAmount)
                .filter(java.util.Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal eligibleItc = invoices.stream()
                .filter(inv -> inv.getItcEligibility() != null && inv.getItcEligibility().contains("Eligible"))
                .map(Invoice::getItcAmount)
                .filter(java.util.Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal blockedItc = invoices.stream()
                .filter(inv -> inv.getItcEligibility() != null && inv.getItcEligibility().contains("Ineligible"))
                .map(inv -> nz(inv.getCgst()).add(nz(inv.getSgst())).add(nz(inv.getIgst())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        long pendingCount = invoices.stream().filter(i -> "Pending".equalsIgnoreCase(i.getStatus())).count();
        long flaggedCount = invoices.stream().filter(i -> "Flagged".equalsIgnoreCase(i.getStatus())).count();
        long approvedCount = invoices.stream().filter(i -> "Approved".equalsIgnoreCase(i.getStatus())).count();

        return Map.of(
                "totalInvoices", invoices.size(),
                "totalSpend", totalSpend,
                "eligibleItc", eligibleItc,
                "blockedItc", blockedItc,
                "pendingCount", pendingCount,
                "flaggedCount", flaggedCount,
                "approvedCount", approvedCount
        );
    }

    private BigDecimal nz(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private String generateInvoiceId() {
        int year = Year.now().getValue();
        int random = ThreadLocalRandom.current().nextInt(1000, 10000);
        String candidate = "INV-" + year + "-" + random;
        // avoid collisions on the (unlikely) chance of a duplicate
        while (invoiceRepository.existsById(candidate)) {
            random = ThreadLocalRandom.current().nextInt(1000, 10000);
            candidate = "INV-" + year + "-" + random;
        }
        return candidate;
    }
}
